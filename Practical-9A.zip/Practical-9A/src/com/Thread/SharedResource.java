package com.Thread;

public class SharedResource {
    public static int number = 1;
    public static final int MAX_NUMBER = 15;
    public static final Object lock = new Object();
}
